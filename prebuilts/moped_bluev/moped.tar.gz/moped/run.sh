#!/bin/bash

SCRIPT_DIR=$( cd -- "$( dirname -- "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )
NUM_ARG=`echo $#`

# reconfig testbed
if [[ "$NUM_ARG" == "1" ]]
then
  HU=$1
  sed -i "s/HU/$HU/" "$SCRIPT_DIR"/testbed1.yaml
  "$SCRIPT_DIR"/bluev_test_suite_executable -c "$SCRIPT_DIR"/testbed1.yaml
elif [[ "$NUM_ARG" == "2" ]]
then
  HU=$1
  PHONE1=$2
  sed -i "s/HU/$HU/" "$SCRIPT_DIR"/testbed2.yaml
  sed -i "s/PHONE1/$PHONE1/" "$SCRIPT_DIR"/testbed2.yaml
  "$SCRIPT_DIR"/bluev_test_suite_executable -c "$SCRIPT_DIR"/testbed2.yaml
elif [[ "$NUM_ARG" == "3" ]]
then
  HU=$1
  PHONE1=$2
  PHONE1=$3
  sed -i "s/HU/$HU/" "$SCRIPT_DIR"/testbed3.yaml
  sed -i "s/PHONE1/$PHONE1/" "$SCRIPT_DIR"/testbed3.yaml
  sed -i "s/PHONE2/$PHONE2/" "$SCRIPT_DIR"/testbed3.yaml
  "$SCRIPT_DIR"/bluev_test_suite_executable -c "$SCRIPT_DIR"/testbed3.yaml
elif [[ "$NUM_ARG" == "4" ]]
then
  HU=$1
  PHONE1=$2
  PHONE2=$3
  PHONE3=$4
  sed -i "s/HU/$HU/" "$SCRIPT_DIR"/testbed4.yaml
  sed -i "s/PHONE1/$PHONE1/" "$SCRIPT_DIR"/testbed4.yaml
  sed -i "s/PHONE2/$PHONE2/" "$SCRIPT_DIR"/testbed4.yaml
  sed -i "s/PHONE3/$PHONE3/" "$SCRIPT_DIR"/testbed4.yaml
  "$SCRIPT_DIR"/bluev_test_suite_executable -c "$SCRIPT_DIR"/testbed4.yaml
else
  echo "argument wrong, please check your config!"
fi

